# Individual Project Summary & Submission Document
**Cisco Virtual Internship Program (VIP) 2026 | Networking**

---

## 1. Student & Institutional Identification

- **Student Name**: K. Sai Manikanta
- **Roll Number / Student ID**: 2023002625
- **Branch / Specialization**: CSE Core (Computer Science & Engineering)
- **Institution / University Name**: GITAM University
- **Technology Domain**: Networking & Python Network Assurance
- **Project Title**: SmartBranch 360 - Secure Branch Office Network Architecture & Automated Assurance Tool
- **Individual Role**: Lead Network Security & Automation Engineer

---

## 2. Executive Problem Statement & Real-World Challenge

In enterprise networking, establishing a new branch office requires segregated traffic flows, secure multi-VLAN routing, dynamic IP management, and WAN edge address translation. Right now, manual device configuration across multiple switches and routers often leads to configuration errors, security breaches, and untracked network outages.

Without an automated assurance framework:
1. **Security Isolation Failures**: Visitors on Guest Wi-Fi could gain unauthorized access to internal corporate databases, server VLANs, or administrative management interfaces.
2. **IP Address & Gateway Conflicts**: Misconfigured default gateways or missing trunk VLANs drop critical employee traffic.
3. **Configuration Drift**: Human error during Cisco IOS CLI configuration goes undetected until end-users experience downtime.

To solve this challenge, I designed and deployed **SmartBranch 360** in Cisco Packet Tracer, implemented robust multi-tier security boundaries, and developed a custom Python Network Assurance script (`smartbranch_checker.py`) to audit and validate live network configurations automatically.

---

## 3. My Individual Technical Contributions

As the Lead Network Security & Automation Engineer for this project, I personally designed, configured, and validated the following core components:

### 3.1 Network Architecture & Multi-VLAN Subnet Plan
I designed a 4-VLAN network topology supporting corporate employees, visitor guests, enterprise servers, and infrastructure administration:
- **VLAN 10 (Employee)**: Subnet `10.10.10.0/24`, Gateway `10.10.10.1`, DHCP Range `10.10.10.50 - 10.10.10.254`.
- **VLAN 20 (Guest)**: Subnet `10.10.20.0/24`, Gateway `10.10.20.1`, DHCP Range `10.10.20.50 - 10.10.20.254`.
- **VLAN 30 (Server)**: Subnet `10.10.30.0/24`, Gateway `10.10.30.1`, Static Server IP `10.10.30.10`.
- **VLAN 99 (Management)**: Subnet `10.10.99.0/24`, Gateway `10.10.99.1`, Static Admin IP `10.10.99.10`.

### 3.2 Cisco IOS Router & Switch Infrastructure Configuration
- **Router-on-a-Stick Inter-VLAN Routing**: Configured 802.1Q trunk sub-interfaces on Router `R1` (`Gig0/0.10`, `Gig0/0.20`, `Gig0/0.30`, `Gig0/0.99`).
- **Dynamic NAT Overload (PAT)**: Activated dynamic PAT on WAN interface `Gig0/1` allowing internal private subnets (`10.10.0.0/16`) to communicate out to the ISP Cloud (`203.0.113.1`).
- **Switch Infrastructure (SW1 & SW2)**: Created VLAN databases across Core Switch `SW1` and Access Switch `SW2`, configured 802.1Q trunk links with native VLAN 99, and mapped access port ranges to ensure plug-and-play port assignment.

### 3.3 Zero-Trust Security ACL & SSH Management Hardening
- **Guest Isolation Extended ACL (`GUEST_ISOLATION_ACL`)**: Configured on sub-interface `Gig0/0.20`:
  1. `permit udp 10.10.20.0 0.0.0.255 host 10.10.30.10 eq domain` (Allows Guest DNS resolution).
  2. `deny ip 10.10.20.0 0.0.0.255 10.10.30.0 0.0.0.255` (Blocks Guest access to Server VLAN 30).
  3. `deny ip 10.10.20.0 0.0.0.255 10.10.99.0 0.0.0.255` (Blocks Guest access to Management VLAN 99).
  4. `permit ip 10.10.20.0 0.0.0.255 any` (Permits outward Internet access).
- **SSH Hardening**: Enforced SSH Version 2 on VTY lines (`transport input ssh`), generating 2048-bit RSA keys, and restricted administrative login strictly to Management VLAN 99 (`access-class 10 in`).

### 3.4 Python Assurance Checker Tool Development (`smartbranch_checker.py`)
I engineered a custom Python verification tool using regular expression pattern matching and structured object parsing:
- Audits requirement files (`network_plan.yaml` / `network_plan.json`) against Cisco `show` outputs.
- Automatically flags configuration anomalies (missing trunk VLANs, incorrect gateway IPs, broken DHCP pools, missing NAT rules, ACL blocks).
- Outputs clear root cause findings and exact copy-pasteable Cisco IOS CLI fix commands.
- Verified with automated unit testing (`python -m unittest tests/test_checker.py` -> 6/6 PASS).

---

## 4. Experimental Testing & Verification Results

I conducted empirical testing inside Cisco Packet Tracer to validate functional and security requirements:

### 4.1 Employee Connectivity Test (VLAN 10 -> VLAN 30)
- **Action**: From Employee PC 1 (`10.10.10.50`), executed `ping 10.10.30.10`.
- **Result**: `Reply from 10.10.30.10: bytes=32 time=12ms TTL=127` (**SUCCESS** - Inter-VLAN routing & server access confirmed).

### 4.2 Guest Isolation Security Enforcement Test (VLAN 20 -> VLAN 30)
- **Action**: From Guest PC 1 (`10.10.20.50`), executed `ping 10.10.30.10`.
- **Result**: `Request timed out / Destination Host Unreachable` (**SUCCESS** - Security ACL block enforced).

### 4.3 Python Assurance Tool Audit Execution
- Executed: `python smartbranch_checker.py --plan network_plan.json --config cisco_configs/sample_show_outputs/working_network.txt`.
- Output: **100% PASS (13/13 rules validated with zero failures)**.

---

## 5. Learning Outcomes & Professional Reflection

Through this project, I gained extensive practical mastery in:
1. Enterprise Cisco IOS CLI configuration for routers, switches, and security ACLs.
2. Implementing 802.1Q trunking protocols, sub-interface encapsulation, and dynamic PAT overload.
3. Designing Zero-Trust network boundaries for multi-tenant VLAN environments.
4. Writing Python scripts to automate network compliance auditing and infrastructure assurance.

---

## 6. Student Declaration

I hereby declare that this Summary Document represents my own individual work, technical contribution, and original analysis for the Cisco Virtual Internship Program 2026.

- **Student Name**: K. Sai Manikanta
- **Roll Number**: 2023002625
- **Institution**: GITAM University
- **Date**: August 30, 2026
